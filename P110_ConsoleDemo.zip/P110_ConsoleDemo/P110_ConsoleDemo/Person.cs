﻿using System;

namespace P110_ConsoleDemo
{
    class Person
    {
        public string Firstname;
        public string Lastname;
        public DateTime Birthdate;
        public Person Father;

        //constructor is a method without return type & name must be the same as class name
        public Person()
        {
            Console.WriteLine("New person was born.");
        }

        public Person(string firstname, string lastname) : this()
        {
            Firstname = firstname;
            Lastname = lastname;
        }

        public Person(string firstname, string lastname, DateTime birthdate) : this(firstname, lastname)
        {
            Birthdate = birthdate;
        }

        public string TellName()
        {
            return $"{Firstname} {Lastname}";
        }

        public int TellAge()
        {
            return DateTime.Now.Year - Birthdate.Year;
        }

        public virtual string ShowFullInfo()
        {
            return $"{TellName()} {TellAge()}  years old";
        }
    }



}
