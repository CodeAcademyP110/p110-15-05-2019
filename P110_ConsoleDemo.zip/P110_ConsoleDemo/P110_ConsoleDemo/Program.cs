﻿using System;
using System.Text;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Homework - working with arrays
            //int[] allNumbers = { 10, 15, 23, 12, 24, 45, 4 };
            //int[] evenNumbers = FilterArray(allNumbers);

            //Console.WriteLine("Nece ededlik massiv yaratmaq isteyirsinzikdhifds?");
            //int arraySize = int.Parse(Console.ReadLine());

            //int[] arr = new int[arraySize];

            //for (int i = 0; i < arraySize; i++)
            //{
            //    Console.Write($"{i+1}-ci ededi daxil edin:");
            //    arr[i] = int.Parse(Console.ReadLine());
            //}

            //foreach (var item in evenNumbers)
            //{
            //    Console.WriteLine(item);
            //}
            #endregion

            #region Multidimensional array
            //string[,,] n = new string[3, 2, 2];

            //for (int i = 0; i < n.GetLength(0); i++)
            //{
            //    for (int j = 0; j < n.GetLength(1); j++)
            //    {
            //        for (int g = 0; g < n.GetLength(2); g++)
            //        {
            //            Console.Write($"Korpus: {i}, Mertebe: {j}, Otaq: {g}-da yasayani daxil edin => ");
            //            string client = Console.ReadLine();
            //            n[i, j, g] = client;
            //        }
            //    }
            //}


            //for (int i = 0; i < n.GetLength(0); i++)
            //{
            //    for (int j = 0; j < n.GetLength(1); j++)
            //    {
            //        for (int g = 0; g < n.GetLength(2); g++)
            //        {
            //            Console.WriteLine($"Korpus: {i}, Mertebe: {j}, Otaq: {g} => {n[i, j, g]}");
            //        }
            //    }
            //}
            #endregion

            //OOP 3 main principle - Inheritance, Encapsulation, Polymorphism

            Person samir = new Person();
            Person samir2 = new Person("Samir", "Dadash");
            Person samir3 = new Person("Nadir", "Dadash", new DateTime(1999,12,10));

        }

        //static int[] FilterArray(int[] numbers)
        //{
        //    int evenCount = 0;

        //    foreach (int n in numbers)
        //    {
        //        if (n % 2 == 0) evenCount++;
        //    }

        //    int[] evens = new int[evenCount];

        //    int indexEven = 0;
        //    for (int i = 0; i < numbers.Length; i++)
        //    {
        //        if (numbers[i] % 2 == 0) evens[indexEven++] = numbers[i];
        //    }

        //    return evens;
        //}
    }



}
