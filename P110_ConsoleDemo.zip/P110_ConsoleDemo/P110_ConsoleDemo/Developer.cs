﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P110_ConsoleDemo
{
    class Developer : Person
    {
        public string FavouriteProgrammingLanguage;
        public float Experience;
        public string Position;

        public override string ShowFullInfo()
        {
            string exp = Experience <= 1 ? "year" : "years";
            return $"{base.ShowFullInfo()} {Experience} {exp} as {Position}";
        }
    }
}
